# Netronome Shell Environment
NETRONOME_DIR="/opt/netronome"
PATH="${PATH}:${NETRONOME_DIR}/bin"
export NETRONOME_DIR PATH
