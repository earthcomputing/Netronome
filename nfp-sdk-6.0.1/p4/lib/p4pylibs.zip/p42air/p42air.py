#!/usr/bin/python
import argparse
import os
import sys
import collections
import traceback

import p4_hlir_versions as p4hv

import actions
import stateful
import hdrs
import parse
import ctlflow
import srcinfo
import p42air_common

import __version__


def p42air(options, split, p4_source_files, yml_output_filename, p4_defines=[], p4_includes=[]):
    # load up the p4 python runtime IR
    custom_primitives = options['custom_primitives'] if 'custom_primitives' in options else None
    primatives_package = '%s.frontend'%p4hv.p4_hlir.__name__
        
    p4data = p4hv.p4_hlir.main.HLIR(custom_primitives, primatives_package)

    for p4f in p4_source_files:
        p4data.add_src_files(p4f)

    # add custom standard metadata format
    smd = collections.OrderedDict() 
    smd["ingress_port"]       = 10 # port; no channel
    smd["packet_length"]      = 14 # 16k max
    smd["egress_spec"]        = 16 # port + chan
    smd["egress_port"]        = 16 # port + chan
    smd["egress_instance"]    = 10 # max 1k multicast
    smd["instance_type"]      = 4  # eight valid values
    smd["clone_spec" ]        = 32 # opaque identifier

    if p4data.set_standard_metadata(smd) < 0:
        raise p42air_common.P42AIRError("Failed to add custom standard metadata")

    if p4_defines:
        p4data.add_preprocessor_args(*['-D%s'%pd for pd in p4_defines])
    if p4_includes:
        p4data.add_preprocessor_args(*['-I%s'%pi for pi in p4_includes])
    
    if p4data.build() == False:
        raise p42air_common.P42AIRError("Failed to build P4 design")

    entity_namer = p42air_common.entity_namer()

    # generate air data structures for the various stages
    hdrs_data = hdrs.hdrs_gen(p4data, entity_namer)
    stateful_data = stateful.stateful_gen(p4data, entity_namer, options=options)
    parse_data = parse.parse_gen(p4data, entity_namer, options=options)
    actions_data = actions.actions_gen(p4data, entity_namer)
    ctlflow_data = ctlflow.ctlflow_gen(p4data, entity_namer, options=options)
    srcinfo_data = srcinfo.srcinfo_gen(p4data, yml_output_filename)
    
    # write out AIR yaml file(s)
    
    types = ['headers', 'stateful', 'parser', 'actions', 'control', 'srcinfo']
    
    # store open file handle(s)
    outfile_h = {}
    # stores references to open file handles per output type
    outfiles = {}

    p = os.path.dirname(yml_output_filename)
    if p and not os.path.exists(p):
        os.makedirs(p)
    
    if not split:
        outfile_h['all'] = open(yml_output_filename, "w+")
        for t in types:
            outfiles[t] = outfile_h['all']
    else:
        path_split = os.path.splitext(yml_output_filename)
        for t in types:
            outfile_h[t] = open(path_split[0] + "_" + t + path_split[1], "w+")
            outfiles[t] = outfile_h[t]
    
    hdrs.hdrs_output(outfiles['headers'], hdrs_data)
    stateful.stateful_output(outfiles['stateful'], stateful_data)
    parse.parse_output(outfiles['parser'], parse_data, ctlflow_data, options=options)
    actions.actions_output(outfiles['actions'], actions_data, options=options)
    ctlflow.ctlflow_output(outfiles['control'], ctlflow_data, actions_data)
    srcinfo.srcinfo_output(outfiles['srcinfo'], srcinfo_data)
    
    # close all open file handles
    for f in outfile_h:
        outfile_h[f].close()

    if 'interactive' in options:
        import IPython
        IPython.embed()

def main():
    parser = argparse.ArgumentParser(
        description=__version__.DESCRIPTION,
        epilog='Copyright (C) 2016 Netronome Systems, Inc.  All rights reserved.')
    parser.add_argument('--version', action='version', version=__version__.VERSION)
    parser.add_argument('p4_source_files', metavar='p4src',
                        type=str, nargs='+',
                        help='P4 source file')
    
    parser.add_argument('-o', dest='outfilename', type=str, default="air.yml", help="output AIR filename")
    parser.add_argument('-p', dest='parse_graph', type=str, default=None, help="parse graph output file")
    parser.add_argument('-i', dest='ingress_graph', type=str, default=None, help="ingress graph output file")
    parser.add_argument('-e', dest='egress_graph', type=str, default=None, help="egress graph output file")
    parser.add_argument('-c', dest='custom_primitives', type=str, default=None, help="custom primitives JSON")
    parser.add_argument('--source_info', action="store_true",
                        help="include source filename and line number in certain objects")
    parser.add_argument('--split', action="store_true",
                        help="split AIR output into multiple files")
    parser.add_argument('-I', dest='p4_includes', type=str, default=[], action='append',
                        help="p4 preprocessor include paths")
    parser.add_argument('-D', dest='p4_defines', type=str, default=[], action='append',
                        help="p4 preprocessor defines")
    parser.add_argument('--p4-version', dest='p4_version', action="store", default='1.0', 
                        choices=('1.0', '1.1'),
                        help="select p4 language version")
    if not hasattr(sys, 'frozen'):
        parser.add_argument('--interactive', action="store_true",
                            help="initiate an interactive shell after building")
    
    args = parser.parse_args()

    p4hv.select_version(args.p4_version)
    
    options = {}
    if args.source_info == True:
        options['src_info'] = True
    if not hasattr(sys, 'frozen') and args.interactive == True:
        options['interactive'] = True
    if args.parse_graph != None:
        options['parse_graph'] = args.parse_graph
    if args.ingress_graph != None:
        options['ingress_graph'] = args.ingress_graph
    if args.egress_graph != None:
        options['egress_graph'] = args.egress_graph
    if args.custom_primitives != None:
        options['custom_primitives'] = args.custom_primitives

    try:
        p42air(options, args.split, args.p4_source_files, args.outfilename, args.p4_defines, args.p4_includes)
    except p42air_common.P42AIRError, err:
        print >> sys.stderr, "error: %s"%str(err)
        sys.exit(1)        
    except Exception, err:    
        print >> sys.stderr, "unhandled error: %s"%str(err)
        traceback.print_exc()
        sys.exit(1)        
    
if __name__ == '__main__':
    main()
