import sys
import collections
import warnings
import re

import p4_hlir_versions as p4hv

from p42air_common import I, FOUT, expand_expression, P42AIRError

# Check that referenced fields appear before variable length field and that
# there is at most one variable length field.
def check_var_hdr(len_expr, p4hdr):
    flds = p4hdr.layout.keys()
    fld_var = ''
    fld_var_cnt = 0
    fld_var_idx = 0
    flds_ref = []
    flds_ref_idx = []

    # Ensure at most one variable length field.
    for fld in flds:
        if type(p4hdr.layout[fld]) is not int:
            if fld_var_cnt > 0:
                raise P42AIRError("One field at most may be variable length:" +
                                  " (%s) or (%s)." %(fld_var, fld))
            else:
                fld_var_cnt += 1
                fld_var = fld
                fld_var_idx = flds.index(fld)

    # Ensure that referenced fields preceed variable field.
    for fld in flds:
        match_left = re.search(fld+'\W|'+fld+'$', str(len_expr.left))
        match_right = re.search(fld+'\W|'+fld+'$', str(len_expr.right))
        if match_left is not None or match_right is not None:
            if fld == fld_var:
                raise P42AIRError("Length expression cannot reference variable" +
                                  " length field (%s)." %(fld_var))
            else:
                flds_ref.append(fld)
                flds_ref_idx.append(flds.index(fld))
    for ref_idx in flds_ref_idx:
        if ref_idx > fld_var_idx:
            raise P42AIRError("Referenced field (%s) in length " %(flds[ref_idx]) +
                              "expression must preceed variable length field " +
                              "(%s)." %(fld_var))


def hdrs_gen(p4data, entity_namer):
    air_hdr_types = {}

    # Set maximum supported variable header length.
    MAX_VAR_LEN = 256

    # p4_headers describes the field layout only
    for h in p4data.p4_headers:
        airhdr = {}
        airflds = []
        is_var_len = False

        p4hdr = p4data.p4_headers[h]

        entity_namer.register_name(h,
                                   p4hdr.filename,
                                   p4hdr.lineno);

        for lo in p4hdr.layout:
            # store field name and width
            width = p4hdr.layout[lo]
            # Set variable length field widths to 0
            if width == p4hv.p4_hlir.hlir.p4_headers.P4_AUTO_WIDTH:
                width = 0
                is_var_len = True

            airfld = {'name' : lo, 'width' : width}
            p4attr = p4hdr.attributes[lo]
            airfld['attributes'] = []
            for attr in p4attr:
                airfld['attributes'].append(attr)

            airflds.append(airfld)


        airhdr['fields'] = airflds

        if type(p4hdr.max_length) != int:
            raise P42AIRError("max_length must be a constant.")
        # max_length should only be present in variable length header
        if p4hdr.max_length != p4hdr.length and is_var_len is False:
            raise P42AIRError("max_length attribute must not be present in " +
                              "fixed length header.")
        # Ensure max_length is less than system maximum
        if p4hdr.max_length > MAX_VAR_LEN:
            warnings.warn("max_length of header exceeds the recommended " +
                          "system maximum of (%d) bytes." %(MAX_VAR_LEN))
        airhdr['max_length'] = p4hdr.max_length

        # Save expression for variable length header.
        if type(p4hdr.length) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
            # Ensure referenced fields appear before variable length field.
            check_var_hdr(p4hdr.length, p4hdr)
            airhdr['length'] = expand_expression(p4hdr.length, 4)
        else:
            airhdr['length'] = p4hdr.length

        # we keep track of how many header instances reference a hdr
        # type; doing this allows us to print the hdr def separately
        # if there are multiple instances using a hdr layout
        airhdr['refcnt'] = 0

        air_hdr_types[h] = airhdr

    air_hdr_instances = {}

    for h in p4data.p4_header_instances:
        airhdri = {}

        p4hdri = p4data.p4_header_instances[h]

        # handle stacked header
        if p4hdri.index != None:
            # FIXME: this approach may or may not be bad
            # the p4 IR has an odd way of representing instantiated stack
            # header; the name has the text "[0..N]|[next][last]"
            # only look at the first header
            if p4hdri.index != 0:
                continue;
            airhdri['max_depth'] = p4hdri.max_index + 1
            # correct the name
            h = h.split('[')[0]
        else:
            airhdri['max_depth'] = 0

        entity_namer.register_name(h,
                                   p4hdri.filename,
                                   p4hdri.lineno);

        airhdri['name'] = h
        airhdri['type'] = p4hdri.header_type.name
        airhdri['ismetadata'] = p4hdri.metadata
        airhdri['doc'] = p4hdri.doc

        # go through the fields and pull out any calculated ones
        calcs = []
        field_inits = collections.OrderedDict()
        for f in p4hdri.fields:
            if f.default not in [None, 0]:
                field_inits[f.name] = f.default
            if len(f.calculation) == 0:
                continue;
            for c in f.calculation:
                calc = {}
                calc['field'] = f.name
                calc['type'] = c[0]
                calc['func'] = c[1].name
                try:
                    calc['condition'] = expand_expression(c[2], 8)
                except P42AIRError, err:
                    calc['condition'] = None
                calcs.append(calc)

        # Check for hardware checksum verification pragma.
        pragmas = []
        for pragma, pragma_obj in p4hdri._parsed_pragmas.items():
            if pragma != 'netro':
                continue
            for pragma in pragma_obj.keys():
                if re.search(r'^((ipv4)|(udp)|(tcp))_header$', pragma) != None:
                    # Header must contain calculated field.
                    if len(calcs) < 1:
                        raise P42AIRError("Pragma (%s) cannot be " \
                                          "associated with header %s " \
                                          "which has no " \
                                          "calculated fields." %(pragma, h))
                    pragmas.append(pragma)
                    break

        airhdri['field_inits'] = field_inits
        airhdri['calcs'] = calcs
        airhdri['pragmas'] = pragmas

        air_hdr_types[airhdri['type']]['refcnt'] += 1

        air_hdr_instances[h] = airhdri

    air_field_lists = {}
    for fl in p4data.p4_field_lists:
        flobj = p4data.p4_field_lists[fl]
        entry = { 'name' : fl, 'doc' : flobj.doc}

        entity_namer.register_name(fl,
                                   flobj.filename,
                                   flobj.lineno);

        flds = []
        for f in flobj.fields:
            if type(f) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
                # if this is padding exclude it
                # note that hlir should really be applying a PADDING
                # attribute to the field
                if f.name == '_padding':
                    continue
                flds.append("%s.%s" % (f.instance.name, f.name));
            elif type(f) == p4hv.p4_hlir.hlir.p4_sized_integer:
                flds.append("%dw%d" % (f.width, f));
            elif type(f) == p4hv.p4_hlir.hlir.p4_header_keywords and \
                 f == p4hv.p4_hlir.hlir.p4_headers.P4_PAYLOAD:
                flds.append("%s" % (f));
            #These are commented out until the back-end supports them
            #elif type(f) == p4hv.p4_hlir.hlir.p4_header_keywords:
            #    flds.append("%s" % (f));
            else:
                raise P42AIRError("Field list '%s' " \
                                  "has entry '%s' with " \
                                  "unsupported type %s" % 
                                  (fl, f, type(f)))
        entry['fields'] = flds
        air_field_lists[fl] = entry

    air_field_calcs = []
    for fc in p4data.p4_field_list_calculations:
        inst = {}
        inst['name'] = fc
        fcobj = p4data.p4_field_list_calculations[fc]
        entity_namer.register_name(fc,
                                   fcobj.filename,
                                   fcobj.lineno);
        inst['algo'] = fcobj.algorithm
        inst['width'] = fcobj.output_width
        inst['inputs'] = []
        for i in fcobj.input:
            inst['inputs'].append(i.name)
        air_field_calcs.append(inst)

    return (air_hdr_types, air_hdr_instances, air_field_lists, air_field_calcs)

#####################################################
# Output code
#####################################################

def hdrs_output(outfile, gen_data):
    air_hdr_types, air_hdr_instances, air_field_lists, air_field_calcs = gen_data

    once = 0
    for h in air_hdr_types:
        if air_hdr_types[h]['refcnt'] <= 1:
            continue

        if once == 0:
            once = 1
            FOUT(outfile, 0, "##########################################\n");
            FOUT(outfile, 0, "# Header layout definitions              #\n");
            FOUT(outfile, 0, "##########################################\n\n");

        FOUT(outfile, 0, '%s : &%s\n'%(h, h))

        for f in air_hdr_types[h]['fields']:
            if len(f['attributes']) == 0:
                FOUT(outfile, 1, '- %s : %d\n' % (f['name'], f['width']))
                continue
            FOUT(outfile, 1, '- %s : \n' % (f['name']))
            FOUT(outfile, 2, '- width : %d \n' % (f['width']))
            for attr in f['attributes']:
                FOUT(outfile, 2, '- %s : True \n' % (attr))
                continue
        FOUT(outfile, 0, '\n');

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Header instance definitions            #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    hdrs = []
    md = []

    # order by pkt headers first, then metadata
    for h in air_hdr_instances:
        hdr = air_hdr_instances[h]
        if hdr['ismetadata']:
            md.append(h)
        else:
            hdrs.append(h)

    for h in hdrs + md:
        hdr = air_hdr_instances[h]

        FOUT(outfile, 0, '%s :\n' %(h))
        if hdr['ismetadata']:
            FOUT(outfile, 1, 'type : metadata\n')
        else:
            FOUT(outfile, 1, 'type : header\n')

        if hdr['doc']:
            FOUT(outfile, 1, 'doc : "%s"\n' % (hdr['doc']))

        if hdr['max_depth']:
            FOUT(outfile, 1, 'max_depth : %d\n' % (hdr['max_depth']))

        if air_hdr_types[hdr['type']]['refcnt'] > 1 :
            FOUT(outfile, 1, 'fields : *%s\n' % (hdr['type']))
        else:
            FOUT(outfile, 1, 'fields : \n');
            for f in air_hdr_types[hdr['type']]['fields']:
                if len(f['attributes']) == 0:
                    FOUT(outfile, 2, '- %s : %d\n' % (f['name'], f['width']))
                    continue
                FOUT(outfile, 2, '- %s : \n' % (f['name']))
                FOUT(outfile, 3, '- width : %d \n' % (f['width']))
                for attr in f['attributes']:
                    FOUT(outfile, 3, '- %s : True \n' % (attr))

        if len(hdr['field_inits']) != 0:
            FOUT(outfile, 1, 'initial_values :\n')
        for fi, fiobj in hdr['field_inits'].items():
            FOUT(outfile, 2, '- %s : 0x%x\n' %(fi, fiobj))

        if len(hdr['calcs']) != 0:
            FOUT(outfile, 1, 'calculated_fields :\n')
        for cf in hdr['calcs']:
            FOUT(outfile, 2, '- field : %s\n' %(cf['field']))
            FOUT(outfile, 2, '  type : %s\n' %(cf['type']))
            FOUT(outfile, 2, '  func : %s\n' %(cf['func']))
            FOUT(outfile, 2, '  condition : %s\n' %(cf['condition']))

        # length (expression) and max_length (constant) will be different for
        # variable length headers.
        if air_hdr_types[hdr['type']]['length'] != \
           air_hdr_types[hdr['type']]['max_length']:
            FOUT(outfile, 1, 'length : %s\n' 
                             %(air_hdr_types[hdr['type']]['length']))
            FOUT(outfile, 1, 'max_length : %d\n'
                             %(air_hdr_types[hdr['type']]['max_length']))

        # Hardware checksum pragma.
        if len(hdr['pragmas']) > 0:
            FOUT(outfile, 1, 'pragmas : \n');
            for pragma in hdr['pragmas']:
                FOUT(outfile, 2, '- %s\n' % (pragma))

        FOUT(outfile, 0, "\n")

    # field lists are not always in designs so we conditionally report the
    # banner
    once = 0
    for fl in air_field_lists:
        flist = air_field_lists[fl]
        if once == 0:
            FOUT(outfile, 0, "##########################################\n");
            FOUT(outfile, 0, "# Field list definitions                 #\n");
            FOUT(outfile, 0, "##########################################\n\n");
            once = 1

        FOUT(outfile, 0, '%s :\n' %(fl))
        FOUT(outfile, 1, 'type : field_list\n')
        if hdr['doc']:
            FOUT(outfile, 1, 'doc : "%s"\n' % (hdr['doc']))
        FOUT(outfile, 1, 'fields :\n');
        for f in flist['fields']:
            FOUT(outfile, 2, '-  %s\n' % (f));
        FOUT(outfile, 0, "\n")

    once = 0
    for fl in air_field_calcs:
        if once == 0:
            FOUT(outfile, 0, "##########################################\n");
            FOUT(outfile, 0, "# Field list calculations                #\n");
            FOUT(outfile, 0, "##########################################\n\n");
            once = 1
        FOUT(outfile, 0, '%s :\n' %(fl['name']))
        FOUT(outfile, 1, 'type : field_list_calculation\n')
        FOUT(outfile, 1, 'algorithm : %s\n' %(fl['algo']));
        FOUT(outfile, 1, 'output_width : %s\n' %(fl['width']));
        FOUT(outfile, 1, 'inputs :\n');
        for i in fl['inputs']:
            FOUT(outfile, 2, '- %s\n' % (i));
        FOUT(outfile, 0, "\n")

