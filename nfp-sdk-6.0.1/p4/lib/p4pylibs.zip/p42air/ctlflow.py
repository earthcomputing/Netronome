import os, sys, collections

import pydot

import p4_hlir_versions as p4hv

from p42air_common import I, FOUT, expand_expression, P42AIRError

# build up the control flow based on a start node
def build_flow(p4data, start):
    transitions = []
    conditionals = collections.OrderedDict()
    tables = []

    if start == None:
        return {"pydot_string" : "",
                "transitions" : transitions,
                "tables" : tables,
                "conditionals" : conditionals,
                "start" : ""}

    if start != None:
        stackdata = [start]
    stackdone = []

    while len(stackdata) != 0:
        op = stackdata.pop(0)
        stackdone.append(op.name)

        if type(op) == p4hv.p4_hlir.hlir.p4_tables.p4_table:
            # dont process the same table twice
            if op in tables:
                continue
            tables.append(op)
            
            # check if all the transitions are to the same place
            # treat this as a special case
            if len(set(op.next_.values())) == 1:
                always = 1
            else:
                always = 0

            for nxt in op.next_:
                transition = {}
                transition['src'] = op.name

                nxtobj = op.next_[nxt]
                if nxtobj == None:
                    # the end
                    transition['dest'] = "exit_control_flow"
                else:
                    transition['dest'] = nxtobj.name

                    # only add the node if it hasn't been added already
                    if transition['dest'] not in stackdone:
                        stackdata.insert(0, nxtobj)

                if always:
                    transition['cond'] = 'action = always'
                elif type(nxt) == str:
                    transition['cond'] = 'action = %s' %(nxt)
                elif type(nxt) == p4hv.p4_hlir.hlir.p4_imperatives.p4_action:
                    transition['cond'] = 'action = %s' %(nxt.name)
                else:
                    raise P42AIRError("Unsupported transition type " +
                                      "%s for table %s\n" % (type(op), op.name))

                transitions.append(transition)

                if always:
                    break

        elif type(op) == p4hv.p4_hlir.hlir.p4_tables.p4_conditional_node:
            # dont process the same conditional twice
            if op.name in conditionals:
                continue

            conditionals[op.name] = op

            # force false then true
            # this forces the true condition to be process on the stack first
            order = [False, True]
            for k in order:
                nxtobj = op.next_[k]

                transition = {}
                transition['src'] = op.name
                if nxtobj == None:
                    transition['dest'] = "exit_control_flow"
                else:
                    transition['dest'] = nxtobj.name

                    # only add the node if it hasn't been added already
                    if transition['dest'] not in stackdone:
                        stackdata.insert(0, nxtobj)
            
                if k == True:
                    transition['cond'] = 'condition = true'
                else:
                    transition['cond'] = 'condition = false'

                transitions.append(transition)
        else:
            raise P42AIRError("Unsupported type in control flow %s\n" % (type(op)))

    # IR dot format
    ir_pydot_string = ""
    ir_pydot_string += 'digraph {\n'
    for t in transitions:
        ir_pydot_string += I(3) + '%s -> %s [%s]\n' % (t['src'], t['dest'], t['cond'])
    ir_pydot_string += I(2) + '}\n'

    return {"ir_pydot_string" : ir_pydot_string,
            "transitions" : transitions,
            "tables" : tables,
            "conditionals" : conditionals,
            "start" : start.name}

def gen_display_pydot(flow):
    conditionals = flow['conditionals']
    transitions = flow['transitions']

    display_pydot_string = ""
    display_pydot_string += 'digraph {\n'
    display_pydot_string += '    graph [fontname = "Courier New", fontsize = "12"];\n'
    display_pydot_string += '    node [fontname = "Courier New", fontsize = "12"];\n'
    display_pydot_string += '    edge [fontname = "Courier New", fontsize = "12"];\n'
    for t in transitions:
        nodes = [t['src'], t['dest']]
        for idx, n in enumerate(nodes):
            if n not in conditionals:
                continue
            PADMAX = 24
            cond = conditionals[n]
            # we pad out conditional so they can be sustituted with the
            # contion in the display engine
            condition = cond['condition']

            constr = "if (" + condition + ")"
            padlen = min(PADMAX, len(constr))

            nodes[idx] = nodes[idx].ljust(padlen)
        
        cond = t['cond']
        args = cond.split('=', 1)
        if len(args) > 1:
            # now args[0] will always have what is behind the first =
            cond = args[1]
        else:
            cond = args[0]


        # only allow a subset of labels, otherwise things get ugly fast
        allowed_labels = ["hit", "miss", "true", "false", "default"]

        if cond.strip() not in allowed_labels:
            cond = ""
        else:
            cond = "label = " + cond.strip()

        display_pydot_string += '    "%s" -> "%s" [%s]\n' % (
                                nodes[0], nodes[1], cond)

    display_pydot_string += '}\n'
    return display_pydot_string

def ctlflow_gen(p4data, entity_namer, options=[]):
    # process control flow
    # egress and ingress

    # find the ingress entry point that has no dependencies
    # this is the ingress entry node
    ingress_flow = {'conditionals' : [], 'tables' : [], 'transitions' : []}
    for k in p4data.p4_ingress_ptr.keys():
        if not k or len(k.dependencies_to) != 0:
            continue
        ingress_flow = build_flow(p4data, k)
        break

    egress_flow = build_flow(p4data, p4data.p4_egress_ptr)

    ingress_condionals = collections.OrderedDict()
    for cname in ingress_flow['conditionals']:
        c = ingress_flow['conditionals'][cname]
        entity_namer.register_name(c.name,
                                   c.filename,
                                   c.lineno);
        ent = {}
        ent['name'] = c.name
        ent['doc'] = c.doc
        if "src_info" in options:
            ent['src_filename'] = c.filename
            ent['src_lineno'] = c.lineno
        ent['condition'] = expand_expression(c.condition, 8)
        ingress_condionals[cname] = ent
    ingress_flow['conditionals'] = ingress_condionals

    egress_condionals = collections.OrderedDict()
    for cname in egress_flow['conditionals']:
        c = egress_flow['conditionals'][cname]
        entity_namer.register_name(c.name,
                                   c.filename,
                                   c.lineno);
        ent = {}
        ent['name'] = c.name
        ent['doc'] = c.doc
        if "src_info" in options:
            ent['src_filename'] = c.filename
            ent['src_lineno'] = c.lineno
        ent['condition'] = expand_expression(c.condition, 8)

        egress_condionals[cname] = ent

    egress_flow['conditionals'] = egress_condionals

    # process tables together
    all_tbls = ingress_flow['tables'] + egress_flow['tables']
    # make sure they are unique
    all_tbls = list(set(all_tbls))

    air_tables = []
    for t in all_tbls:
        entity_namer.register_name(t.name,
                                   t.filename,
                                   t.lineno);
        ent = {}
        ent['name'] = t.name
        ent['doc'] = t.doc
        if "src_info" in options:
            ent['src_filename'] = t.filename
            ent['src_lineno'] = t.lineno

        # get max_entries
        # use the min_size value for the max if defined
        # then override if max_size is defined
        max_entries = None
        if t.min_size:
            max_entries = t.min_size
        if t.max_size:
            max_entries = t.max_size
            
        # add an extra entry for the default rule
        if max_entries:
            max_entries += 1

        ent['max_entries'] = max_entries
        matches = []
        for m in t.match_fields:
            fld, mtype, mask = m
            match = {}
            if type(fld) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
                match['field'] = "%s.%s" % (fld.instance.name, fld.name)
            elif type(fld) == p4hv.p4_hlir.hlir.p4_headers.p4_header_instance:
                match['field'] = "%s" % (fld.name)
            else:
                sys.stderr.write("Unsupported match field type %s for table %s" %
                                  (type(fld), t.name))
                sys.exit(1)

            mt = mtype.value
            mtmap = { "P4_MATCH_EXACT"   : "exact",
                      "P4_MATCH_TERNARY" : "ternary",
                      "P4_MATCH_RANGE"   : "range",
                      "P4_MATCH_LPM"     : "lpm",
                      "P4_MATCH_VALID"   : "valid", }

            if mt not in mtmap:
                sys.stderr.write("Unsupported match type %s for table %s" %
                                  (mt, t.name))
                sys.exit(1)

            match['type'] = mtmap[mt]
            match['mask'] = mask
            matches.append(match)
        ent['matches'] = matches
        
        actions = []
        for a in t.actions:
            actions.append(a.name)
        ent['actions'] = actions

        air_tables.append(ent)

    if "ingress_graph" in options:
        if len(ingress_flow['transitions']) != 0:
            g = pydot.graph_from_dot_data(gen_display_pydot(ingress_flow))
            p = os.path.dirname(options["ingress_graph"])
            if p and not os.path.exists(p):
                os.makedirs(p)
            g.write_svg(options["ingress_graph"])

    if "egress_graph" in options:
        if len(egress_flow['transitions']) != 0:
            g = pydot.graph_from_dot_data(gen_display_pydot(egress_flow))
            p = os.path.dirname(options["egress_graph"])
            if p and not os.path.exists(p):
                os.makedirs(p)
            g.write_svg(options["egress_graph"])


    return (ingress_flow, egress_flow, air_tables)


#####################################################
# Output code
#####################################################

def ctlflow_output(outfile, gen_data, actions_data):
    (ingress_flow, egress_flow, air_tables) = gen_data

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Ingress and Egress tables              #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    for t in air_tables:
        FOUT(outfile, 0, "%s:\n" %(t['name']));
        FOUT(outfile, 1, "type : table\n");
        if t['doc'] != None:
            FOUT(outfile, 1, 'doc : "%s"\n' % (t['doc']));

        if len(t['matches']) > 0:
            FOUT(outfile, 1, 'match_on : \n');
        for m in t['matches']:
            FOUT(outfile, 2, "%s : %s" % (m['field'], m['type']));
            if m['mask'] == None:
                FOUT(outfile, 0, "\n");
            else:
                FOUT(outfile, 0, ", mask 0x%x\n" % (m['mask']));

        if len(t['actions']) > 0:
            FOUT(outfile, 1, 'allowed_actions : \n');
        for a in t['actions']:
            modact = a

            # see if the action for this table has been modified
            modified_actions = actions_data['modified_actions']
            tblname = t['name']
            if t['name'] in modified_actions:
                if a in modified_actions[t['name']]:
                    modact = modified_actions[t['name']][a]

            FOUT(outfile, 2, '- %s\n' % (modact));

        if t['max_entries']:
            FOUT(outfile, 1, 'max_entries : %s\n' %(t['max_entries']))
        if 'src_filename' in t:
            FOUT(outfile, 1, 'src_filename : %s\n' %(t['src_filename']))

        if 'src_lineno' in t:
            FOUT(outfile, 1, 'src_lineno : %s\n' %(t['src_lineno']))

        FOUT(outfile, 0, '\n');

    if len(ingress_flow['transitions']) != 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Ingress conditionals sets              #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for cname, c in ingress_flow['conditionals'].items():
            FOUT(outfile, 0, "%s:\n" %(cname));
            FOUT(outfile, 1, "type : conditional\n");
            FOUT(outfile, 1, 'format : bracketed_expr\n');
            if c['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (c['doc']));
            FOUT(outfile, 1, "condition : \"%s\"\n" % (c['condition']));
            if 'src_filename' in c:
                FOUT(outfile, 1, 'src_filename : %s\n' %(c['src_filename']))

            if 'src_lineno' in c:
                FOUT(outfile, 1, 'src_lineno : %s\n' %(c['src_lineno']))

            FOUT(outfile, 0, '\n');

        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Ingress control flow                   #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        FOUT(outfile, 0, "ingress_flow:\n");
        FOUT(outfile, 1, "type : control_flow\n");
        FOUT(outfile, 1, 'doc : "control flow for ingress"\n');
        FOUT(outfile, 1, 'format : dot\n');
        FOUT(outfile, 1, 'start_state : %s\n' % (ingress_flow['start']));
        FOUT(outfile, 1, 'implementation : >-\n');
        FOUT(outfile, 2, '%s' % ingress_flow['ir_pydot_string'])
        FOUT(outfile, 0, '\n');

    if len(egress_flow['transitions']) != 0:
        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Egress conditionals sets               #\n");
        FOUT(outfile, 0, "##########################################\n\n");
        for cname, c in egress_flow['conditionals'].items():
            FOUT(outfile, 0, "%s:\n" %(c['name']));
            FOUT(outfile, 1, "type : conditional\n");
            FOUT(outfile, 1, 'format : bracketed_expr\n');
            if c['doc'] != None:
                FOUT(outfile, 1, 'doc : "%s"\n' % (c['doc']));
            FOUT(outfile, 1, "condition : \"%s\"\n" % (c['condition']));
            FOUT(outfile, 0, '\n');

        FOUT(outfile, 0, "##########################################\n");
        FOUT(outfile, 0, "# Egress control flow                    #\n");
        FOUT(outfile, 0, "##########################################\n\n");

        FOUT(outfile, 0, "egress_flow:\n");
        FOUT(outfile, 1, "type : control_flow\n");
        FOUT(outfile, 1, 'doc : "control flow for egress"\n');
        FOUT(outfile, 1, 'format : dot\n');
        FOUT(outfile, 1, 'start_state : %s\n' % (egress_flow['start']));
        FOUT(outfile, 1, 'implementation : >-\n');
        FOUT(outfile, 2, '%s' % egress_flow['ir_pydot_string'])
        FOUT(outfile, 0, '\n');

    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Processor layout                       #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    FOUT(outfile, 0, "layout:\n")
    FOUT(outfile, 1, "type : processor_layout\n");
    FOUT(outfile, 1, "format : list\n");
    FOUT(outfile, 1, "implementation :\n");
    FOUT(outfile, 2, "- parser\n");
    if len(ingress_flow['transitions']) != 0:
        FOUT(outfile, 2, "- ingress\n");
    if len(egress_flow['transitions']) != 0:
        FOUT(outfile, 2, "- egress\n");
    FOUT(outfile, 0, '\n');
