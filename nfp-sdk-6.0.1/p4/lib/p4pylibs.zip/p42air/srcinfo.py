import os
import sys
from datetime import datetime

from p42air_common import I, FOUT

ENVVAR_VER_STR='P4_VERSION_STRING'

def srcinfo_gen(p4data, outfilename):

    air_src_info = {}

    air_src_info['srcfiles'] = p4data.source_files
    air_src_info['outfile'] = os.path.split(outfilename)[1]

    air_src_info['date'] = datetime.utcnow().strftime("%Y/%m/%d %H:%M:%S")

    if ENVVAR_VER_STR in os.environ:
        air_src_info['verstr'] = os.environ[ENVVAR_VER_STR]

    return air_src_info

#####################################################
# Output code
#####################################################

def srcinfo_output(outfile, gen_data):
    air_src_info = gen_data
    FOUT(outfile, 0, "##########################################\n");
    FOUT(outfile, 0, "# Source info                            #\n");
    FOUT(outfile, 0, "##########################################\n\n");

    FOUT(outfile, 0, "source_info :\n");
    FOUT(outfile, 1, 'type : source_info\n')

    FOUT(outfile, 1, 'date : %s\n' % (air_src_info['date']))
    if 'verstr' in air_src_info:
        FOUT(outfile, 1, 'version_string : %s\n' %(air_src_info['verstr']))

    FOUT(outfile, 1, 'source_files : \n')
    for f in air_src_info['srcfiles']:
        FOUT(outfile, 2, '- %s\n' % (f))
    FOUT(outfile, 1, 'output_file : %s\n' % (air_src_info['outfile']))
    FOUT(outfile, 0, '\n')
