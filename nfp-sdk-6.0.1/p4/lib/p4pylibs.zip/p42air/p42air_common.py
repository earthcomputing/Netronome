import sys

import p4_hlir_versions as p4hv

INDENT="    "

class P42AIRError(Exception): 
    pass

def I(cnt):
    ret = ""
    for i in range(cnt):
        ret += INDENT
    return ret

def FOUT(fid, indent, text):
    fid.write(I(indent) + text);

class entity_namer(object):
    def __init__(self):
        self.registered_names = {}

    def get_unique_name(self, name):
        tryno = 0
        while 1:
            if tryno > 999:
                break

            new_name = name + "__%d" % tryno
            if new_name not in self.registered_names:
                return new_name

            tryno += 1

        raise P42AIRError("Failed to allocate unique name")


    def register_name(self, name, filename, lineno, error=True):
        if name in self.registered_names:
            rnobj = self.registered_names[name]
            new_name = self.get_unique_name(name)
            if error:
                raise P42AIRError("entity %s %s:%d has name which " \
                                  "clashes with existing entity %s:%d" %
                                  (name, filename, lineno,
                                   rnobj['filename'], rnobj['lineno']))
            else:
                sys.stderr.write("warning: entity %s %s:%d has name which " \
                                 "clashes with existing entity %s:%d; " \
                                 "renaming to %s\n"  %
                                 (name, filename, lineno,
                                  rnobj['filename'], rnobj['lineno'],
                                  newname))
                
            name = new_name

        self.registered_names[name] = { 'filename' : filename,
                                        'lineno'   : lineno }
        return name
            

# recursive expansion expressions into a string
def expand_expression(cond, depth, state = {}):
    if depth == 0:
        raise P42AIRError("Reached recursive limit when expanding expression")

    if cond == None:
        return ""

    if type(cond) in [int, long]:
        return "%d" % (cond)

    if cond.op == 'valid':
        # TODO: check for header instance type here
        return "valid(%s)" % (cond.right.name)

    cast_operation = None
    if type(cond.op) == str:
        if 'ucast' in cond.op or 'icast' in cond.op:
            cast_operation = cond.op[0:5]
            cast_width = int(cond.op.split('(')[1].split(')')[0])

    # ternary is a hack that makes the op a condition
    ternary_condition = None
    if type(cond.op) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
        ternary_condition = cond.op

    outstr = ""
    if ternary_condition:
        outstr += "(" + expand_expression(ternary_condition,
                                          512,
                                          state=state) + ")"
        outstr += " ?: "

    if cond.left:
        state['left'] = cond.left

    if type(cond.left) in [int, long]:
        outstr += "(0x%x) " % (cond.left)
    elif type(cond.left) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
        outstr += "(%s.%s) " % (cond.left.instance.name, cond.left.name)
    # No p4_register_ref attribute in '1.0' 
    elif p4hv.selected_version != p4hv.supported_versions.keys()[0] and \
         type(cond.left) == p4hv.p4_hlir.hlir.p4_imperatives.p4_register_ref:
        outstr += " (%s[%d].value)" % (cond.left.register_name, cond.left.idx)
    elif type(cond.left) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
        outstr += "(%s) " % expand_expression(cond.left, depth - 1, state=state)
    elif type(cond.left) == str:
        outstr += "(%s) " % (cond.left)
    elif cond.left == None:
        pass
    elif type(cond.left) == p4hv.p4_hlir.hlir.p4_imperatives.p4_signature_ref:
        if 'action_signature' not in state:
            raise P42AIRError("No action signature for " \
                              "expression %s : type %s" % (
                              cond.right, type(cond.right)))
        idx = cond.left.idx
        outstr += "(%s)" %(state['action_signature'][idx])
    elif hasattr(p4hv.p4_hlir.hlir.p4_imperatives, 'p4_register_ref') and \
            type(cond.left) == p4hv.p4_hlir.hlir.p4_imperatives.p4_register_ref:
        outstr += " (%s[%d].value)" % (cond.left.register_name, cond.left.idx)
    elif hasattr(p4hv.p4_hlir.hlir, 'p4_sized_integer') and \
            type(cond.left) == p4hv.p4_hlir.hlir.p4_sized_integer:
        # XXX: should we also do a cast?
        outstr += " (%s)" % (str(cond.left))
    else:
        raise P42AIRError("Unsupported expression %s : type %s" % (
                          cond.right, type(cond.right)))

    if ternary_condition:
        state['op'] = "ternary"
    elif cast_operation:
        width_match = False
        try:
            width_match = cond.right.width == cast_width
        except:
            pass
        if type(cond.right) in [int, long]:
            if cast_operation == 'ucast':
                cond.right &= (1 << cast_width) - 1

            else:
                if cond.right >= 0:
                    cond.right &= (1 << (cast_width - 1)) - 1
                else:
                    # convert to 2's complement
                    absval = -cond.right
                    cond.right = (~absval + 1) & ((1 << (cast_width - 1)) - 1)
                    cond.right |= 1 << (cast_width - 1)

        if type(cond.right) not in [int, long] and not width_match:
            outstr += "%s" % (cond.op)
            state['op'] = cond
    else:
        outstr += "%s" % (cond.op)
        state['op'] = cond.op

    state['right'] = cond.right
    if type(cond.right) in [int, long]:
        outstr += " (0x%x)" % (cond.right)
    elif type(cond.right) == p4hv.p4_hlir.hlir.p4_headers.p4_field:
        outstr += " (%s.%s)" % (cond.right.instance.name, cond.right.name)
    elif type(cond.right) == p4hv.p4_hlir.hlir.p4_expressions.p4_expression:
        outstr += " (%s)" % expand_expression(cond.right, depth - 1, state=state)
    elif type(cond.right) == str:
        outstr += "(%s)" % (cond.right)
    elif type(cond.right) == p4hv.p4_hlir.hlir.p4_imperatives.p4_signature_ref:
        if 'action_signature' not in state:
            raise P42AIRError("No action signature for " \
                              "expression %s : type %s" % (
                              cond.right, type(cond.right)))
        idx = cond.right.idx
        outstr += "(%s)" %(state['action_signature'][idx])
    elif hasattr(p4hv.p4_hlir.hlir.p4_imperatives, 'p4_register_ref') and \
            type(cond.right) == p4hv.p4_hlir.hlir.p4_imperatives.p4_register_ref:
        outstr += " (%s[%d].value)" % (cond.right.register_name, cond.right.idx)
    elif hasattr(p4hv.p4_hlir.hlir, 'p4_sized_integer') and \
            type(cond.right) == p4hv.p4_hlir.hlir.p4_sized_integer:
        # XXX: should we also do a cast?
        outstr += " (%s)" % (str(cond.right))
    else:
        raise P42AIRError("Unsupported expression type %s : %s" % (
                          cond.right, type(cond.right)))

    return outstr
