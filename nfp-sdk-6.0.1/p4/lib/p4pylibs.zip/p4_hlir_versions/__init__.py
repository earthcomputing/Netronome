# Package initialisation

import os

import p4_hlir_v1_0, p4_hlir_v1_0.main
import p4_hlir_v1_0, p4_hlir_v1_1.main

supported_versions = {
    '1.0': p4_hlir_v1_0,
    '1.1': p4_hlir_v1_1,
}

selected_version = None
p4_hlir = None

def select_version(version):
    assert version in ('1.0', '1.1')
    global p4_hlir, selected_version
    p4_hlir = supported_versions[version]
    selected_version = version

# for zip library mode we patch the root path function to the include path outside the zip
__target_root_v1_1 = p4_hlir_v1_1.main.target_root
def _target_root_v1_1():
    tr = __target_root_v1_1()
    path_segs = os.path.normpath(tr).split(os.sep)
    if path_segs[-4:] == ['lib', 'p4pylibs.zip', 'p4_hlir_versions', 'p4_hlir_v1_1']:
        tr = os.path.join(*(path_segs[:-4] + ['include', '1.1']))
    return tr
p4_hlir_v1_1.main.target_root = _target_root_v1_1
